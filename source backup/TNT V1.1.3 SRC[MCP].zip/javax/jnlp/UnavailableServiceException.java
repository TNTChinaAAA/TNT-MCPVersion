package javax.jnlp;

public class UnavailableServiceException extends Exception {
   public UnavailableServiceException() {
   }

   public UnavailableServiceException(String var1) {
      super(var1);
   }
}
