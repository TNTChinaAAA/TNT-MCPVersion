package javax.jnlp;

public interface SingleInstanceListener {
   void newActivation(String[] var1);
}
