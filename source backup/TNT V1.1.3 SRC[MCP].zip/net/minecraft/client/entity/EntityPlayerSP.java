package net.minecraft.client.entity;

import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFence;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.BlockWall;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.MovingSoundMinecartRiding;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.GuiCommandBlock;
import net.minecraft.client.gui.GuiEnchantment;
import net.minecraft.client.gui.GuiHopper;
import net.minecraft.client.gui.GuiMerchant;
import net.minecraft.client.gui.GuiRepair;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiScreenBook;
import net.minecraft.client.gui.inventory.GuiBeacon;
import net.minecraft.client.gui.inventory.GuiBrewingStand;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.gui.inventory.GuiCrafting;
import net.minecraft.client.gui.inventory.GuiDispenser;
import net.minecraft.client.gui.inventory.GuiEditSign;
import net.minecraft.client.gui.inventory.GuiFurnace;
import net.minecraft.client.gui.inventory.GuiScreenHorseInventory;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.command.server.CommandBlockLogic;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityMultiPart;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.boss.EntityDragonPart;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C01PacketChatMessage;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.client.C0CPacketInput;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.client.C13PacketPlayerAbilities;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.potion.Potion;
import net.minecraft.stats.AchievementList;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatFileWriter;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;
import net.minecraft.util.ReportedException;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.World;
import net.tntchina.client.event.EventManager;
import net.tntchina.client.event.events.LivingUpdateEvent;
import net.tntchina.client.event.events.MotionUpdateEvent;
import net.tntchina.client.event.events.MoveEvent;
import net.tntchina.client.event.events.SafeWalkEvent;
import net.tntchina.client.event.events.UpdateEvent;
import net.tntchina.client.event.events.UpdatePostEvent;
import net.tntchina.client.event.events.UpdatePreEvent;
import net.tntchina.client.event.events.VelocityEvent;
import net.tntchina.client.module.Module;
import net.tntchina.client.module.ModuleManager;
import net.tntchina.client.module.modules.combat.Velocity;
import net.tntchina.client.module.modules.movement.BugUp;
import net.tntchina.client.module.modules.movement.Climb;
import net.tntchina.client.module.modules.movement.HighJump;
import net.tntchina.client.module.modules.movement.KeepSprint;
import net.tntchina.client.module.modules.movement.NoSlow;
import net.tntchina.client.module.modules.player.HitBox;
import net.tntchina.client.module.modules.player.NoHungry;
import net.tntchina.inject.IEntityPlayerSP;

public class EntityPlayerSP extends AbstractClientPlayer implements IEntityPlayerSP
{
    public final NetHandlerPlayClient sendQueue;
    public final StatFileWriter statWriter;
    public float cacheStrafe = 0.0F, cacheForward = 0.0F, cacheYaw = 0.0F, cachePitch = 0.0F;
    /**
     * The last X position which was transmitted to the server, used to determine when the X position changes and needs
     * to be re-trasmitted
     */
    public double lastReportedPosX;

    /**
     * The last Y position which was transmitted to the server, used to determine when the Y position changes and needs
     * to be re-transmitted
     */
    public double lastReportedPosY;

    /**
     * The last Z position which was transmitted to the server, used to determine when the Z position changes and needs
     * to be re-transmitted
     */
    public double lastReportedPosZ;

    /**
     * The last yaw value which was transmitted to the server, used to determine when the yaw changes and needs to be
     * re-transmitted
     */
    public float lastReportedYaw;

    /**
     * The last pitch value which was transmitted to the server, used to determine when the pitch changes and needs to
     * be re-transmitted
     */
    public float lastReportedPitch;

    /** the last sneaking state sent to the server */
    public boolean serverSneakState;

    /** the last sprinting state sent to the server */
    public boolean serverSprintState;

    /**
     * Reset to 0 every time position is sent to the server, used to send periodic updates every 20 ticks even when the
     * player is not moving.
     */
    public int positionUpdateTicks;
    public boolean hasValidHealth;
    public String clientBrand;
    public MovementInput movementInput;
    protected Minecraft mc;

    /**
     * Used to tell if the player pressed forward twice. If this is at 0 and it's pressed (And they are allowed to
     * sprint, aka enough food on the ground etc) it sets this to 7. If it's pressed and it's greater than 0 enable
     * sprinting.
     */
    protected int sprintToggleTimer;

    /** Ticks left before sprinting is disabled. */
    public int sprintingTicksLeft;
    public float renderArmYaw;
    public float renderArmPitch;
    public float prevRenderArmYaw;
    public float prevRenderArmPitch;
    public int horseJumpPowerCounter;
    public float horseJumpPower;

    /** The amount of time an entity has been in a Portal */
    public float timeInPortal;

    /** The amount of time an entity has been in a Portal the previous tick */
    public float prevTimeInPortal;

    public EntityPlayerSP(Minecraft mcIn, World worldIn, NetHandlerPlayClient netHandler, StatFileWriter statFile)
    {
        super(worldIn, netHandler.getGameProfile());
        this.sendQueue = netHandler;
        this.statWriter = statFile;
        this.mc = mcIn;
        this.dimension = 0;
    }

    /**
     * Called when the entity is attacked.
     */
    public boolean attackEntityFrom(DamageSource source, float amount)
    {
        return false;
    }
    
	public float getCollisionBorderSize() {
		HitBox hitBox = ModuleManager.getModule(HitBox.class);
		return hitBox.getState() ? hitBox.getValue() : super.getCollisionBorderSize();
	}

	public boolean isOnLadder() {
		Climb climb = ModuleManager.getModule(Climb.class);

		if (this.isCollidedHorizontally && climb.getState()) {
			return true;
		}

		return super.isOnLadder();
	}

	protected void setBeenAttacked() {
		Velocity module = ModuleManager.getModule(Velocity.class);

		if (module.getState()) {
			return;
		}

		super.setBeenAttacked();
	}

	public void setVelocity(double x, double y, double z) {
		VelocityEvent event = new VelocityEvent(this.motionX, this.motionY, this.motionZ);
		EventManager.callEvent(event);

		if (event.isCancelled()) {
			return;
		}

		x = event.getX();
		y = event.getY();
		z = event.getZ();

		super.setVelocity(x, y, z);
	}

	public void addVelocity(double x, double y, double z) {
		VelocityEvent event = new VelocityEvent(this.motionX, this.motionY, this.motionZ);
		EventManager.callEvent(event);

		if (event.isCancelled()) {
			return;
		}

		x = event.getX();
		y = event.getY();
		z = event.getZ();
		super.addVelocity(x, y, z);
	}

	public void addExhaustion(float hungryLevel) {
		final NoHungry noHurgry = ModuleManager.getModule(NoHungry.class);

		if (noHurgry.getState()) {
			return;
		} else {
			super.addExhaustion(hungryLevel);
		}
	}

	public float getJumpUpwardsMotion() {
		final HighJump highJump = ModuleManager.getModule(HighJump.class);

		if (highJump.getState()) {
			return highJump.getJumpHigh();
		}

		return 0.42F;
	}

	public void moveEntity(double x, double y, double z) {
		final MoveEvent event = new MoveEvent(x, y, z);
		EventManager.callEvent(event);
		this.onMoveEntity(event.getMotionX(), event.getMotionY(), event.getMotionZ());
	}

    public void attackTargetEntityWithCurrentItem(Entity targetEntity) {
    	if (targetEntity.canAttackWithItem())
        {
            if (!targetEntity.hitByEntity(this))
            {
                float f = (float)this.getEntityAttribute(SharedMonsterAttributes.attackDamage).getAttributeValue();
                int i = 0;
                float f1 = 0.0F;

                if (targetEntity instanceof EntityLivingBase)
                {
                    f1 = EnchantmentHelper.func_152377_a(this.getHeldItem(), ((EntityLivingBase)targetEntity).getCreatureAttribute());
                }
                else
                {
                    f1 = EnchantmentHelper.func_152377_a(this.getHeldItem(), EnumCreatureAttribute.UNDEFINED);
                }

                i = i + EnchantmentHelper.getKnockbackModifier(this);

                if (this.isSprinting())
                {
                    ++i;
                }

                if (f > 0.0F || f1 > 0.0F)
                {
                    boolean flag = this.fallDistance > 0.0F && !this.onGround && !this.isOnLadder() && !this.isInWater() && !this.isPotionActive(Potion.blindness) && this.ridingEntity == null && targetEntity instanceof EntityLivingBase;

                    if (flag && f > 0.0F)
                    {
                        f *= 1.5F;
                    }

                    f = f + f1;
                    boolean flag1 = false;
                    int j = EnchantmentHelper.getFireAspectModifier(this);

                    if (targetEntity instanceof EntityLivingBase && j > 0 && !targetEntity.isBurning())
                    {
                        flag1 = true;
                        targetEntity.setFire(1);
                    }

                    double d0 = targetEntity.motionX;
                    double d1 = targetEntity.motionY;
                    double d2 = targetEntity.motionZ;
                    boolean flag2 = targetEntity.attackEntityFrom(DamageSource.causePlayerDamage(this), f);

                    if (flag2)
                    {
                        if (i > 0)
                        {
                            targetEntity.addVelocity((double)(-MathHelper.sin(this.rotationYaw * (float)Math.PI / 180.0F) * (float)i * 0.5F), 0.1D, (double)(MathHelper.cos(this.rotationYaw * (float)Math.PI / 180.0F) * (float)i * 0.5F));
                            
                            if (!ModuleManager.getModuleState(KeepSprint.class)) {
                                this.motionX *= 0.6D;
                                this.motionZ *= 0.6D;
                                this.setSprinting(false);
                            }
                        }

                        if (targetEntity instanceof EntityPlayerMP && targetEntity.velocityChanged)
                        {
                            ((EntityPlayerMP)targetEntity).playerNetServerHandler.sendPacket(new S12PacketEntityVelocity(targetEntity));
                            targetEntity.velocityChanged = false;
                            targetEntity.motionX = d0;
                            targetEntity.motionY = d1;
                            targetEntity.motionZ = d2;
                        }

                        if (flag)
                        {
                            this.onCriticalHit(targetEntity);
                        }

                        if (f1 > 0.0F)
                        {
                            this.onEnchantmentCritical(targetEntity);
                        }

                        if (f >= 18.0F)
                        {
                            this.triggerAchievement(AchievementList.overkill);
                        }

                        this.setLastAttacker(targetEntity);

                        if (targetEntity instanceof EntityLivingBase)
                        {
                            EnchantmentHelper.applyThornEnchantments((EntityLivingBase)targetEntity, this);
                        }

                        EnchantmentHelper.applyArthropodEnchantments(this, targetEntity);
                        ItemStack itemstack = this.getCurrentEquippedItem();
                        Entity entity = targetEntity;

                        if (targetEntity instanceof EntityDragonPart)
                        {
                            IEntityMultiPart ientitymultipart = ((EntityDragonPart)targetEntity).entityDragonObj;

                            if (ientitymultipart instanceof EntityLivingBase)
                            {
                                entity = (EntityLivingBase)ientitymultipart;
                            }
                        }

                        if (itemstack != null && entity instanceof EntityLivingBase)
                        {
                            itemstack.hitEntity((EntityLivingBase)entity, this);

                            if (itemstack.stackSize <= 0)
                            {
                                this.destroyCurrentEquippedItem();
                            }
                        }

                        if (targetEntity instanceof EntityLivingBase)
                        {
                            this.addStat(StatList.damageDealtStat, Math.round(f * 10.0F));

                            if (j > 0)
                            {
                                targetEntity.setFire(j * 4);
                            }
                        }

                        this.addExhaustion(0.3F);
                    }
                    else if (flag1)
                    {
                        targetEntity.extinguish();
                    }
                }
            }
        }
    }
    
    /**
     * Heal living entity (param: amount of half-hearts)
     */
    public void heal(float healAmount)
    {
    }

    /**
     * Called when a player mounts an entity. e.g. mounts a pig, mounts a boat.
     */
    public void mountEntity(Entity entityIn)
    {
        super.mountEntity(entityIn);

        if (entityIn instanceof EntityMinecart)
        {
            this.mc.getSoundHandler().playSound(new MovingSoundMinecartRiding(this, (EntityMinecart)entityIn));
        }
    }
    
	public void preparePlayerToSpawn() {
		super.preparePlayerToSpawn();
		BugUp.getInstance().spawn = true;
	}

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        if (this.worldObj.isBlockLoaded(new BlockPos(this.posX, 0.0D, this.posZ)))
        {
        	EventManager.callEvent(new UpdatePreEvent());
    		EventManager.callEvent(new UpdateEvent(UpdateEvent.State.PRE));

    		for (Module m : ModuleManager.getModules()) {
    			m.onUpdate();
    		}
    		
            super.onUpdate();

            if (this.isRiding())
            {
                this.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(this.rotationYaw, this.rotationPitch, this.onGround));
                this.sendQueue.addToSendQueue(new C0CPacketInput(this.moveStrafing, this.moveForward, this.movementInput.jump, this.movementInput.sneak));
            }
            else
            {
                this.onUpdateWalkingPlayer();
            }
            
    		EventManager.callEvent(new UpdatePostEvent());
    		EventManager.callEvent(new UpdateEvent(UpdateEvent.State.POST));
        }
    }
    
    public void func_178990_AbNw() {
		this.cacheYaw = this.rotationYaw;
		this.cachePitch = this.rotationPitch;
		MotionUpdateEvent event = new MotionUpdateEvent(MotionUpdateEvent.State.PRE, this.rotationYaw, this.rotationPitch, this.onGround, this.motionX, this.motionY, this.motionZ);
		EventManager.callEvent(event);

		for (Module m : ModuleManager.getModules()) {
			m.onMotion(event);
		}

		this.motionX = event.getX();
		this.motionY = event.getY();
		this.motionZ = event.getZ();
		this.onGround = event.onGround();
		this.rotationYaw = event.getYaw();
		this.rotationPitch = event.getPitch();
    }

    public void func_8821Kns_0PP() {
		MotionUpdateEvent event = new MotionUpdateEvent(MotionUpdateEvent.State.PRE, this.rotationYaw, this.rotationPitch, this.onGround, this.motionX, this.motionY, this.motionZ);
		EventManager.callEvent(event);

		for (Module m : ModuleManager.getModules()) {
			m.onMotion(event);
		}

		this.motionX = event.getX();
		this.motionY = event.getY();
		this.motionZ = event.getZ();
		this.onGround = event.onGround();
		this.rotationYaw = this.cacheYaw;
		this.rotationPitch = this.cachePitch;
    }
    
    /**
     * called every tick when the player is on foot. Performs all the things that normally happen during movement.
     */
    public void onUpdateWalkingPlayer()
    {
    	this.func_178990_AbNw();
        boolean flag = this.isSprinting();

        if (flag != this.serverSprintState)
        {
            if (flag)
            {
                this.sendQueue.addToSendQueue(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.START_SPRINTING));
            }
            else
            {
                this.sendQueue.addToSendQueue(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.STOP_SPRINTING));
            }

            this.serverSprintState = flag;
        }

        boolean flag1 = this.isSneaking();

        if (flag1 != this.serverSneakState)
        {
            if (flag1)
            {
                this.sendQueue.addToSendQueue(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.START_SNEAKING));
            }
            else
            {
                this.sendQueue.addToSendQueue(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.STOP_SNEAKING));
            }

            this.serverSneakState = flag1;
        }

        if (this.isCurrentViewEntity())
        {
            double d0 = this.posX - this.lastReportedPosX;
            double d1 = this.getEntityBoundingBox().minY - this.lastReportedPosY;
            double d2 = this.posZ - this.lastReportedPosZ;
            double d3 = (double)(this.rotationYaw - this.lastReportedYaw);
            double d4 = (double)(this.rotationPitch - this.lastReportedPitch);
            boolean flag2 = d0 * d0 + d1 * d1 + d2 * d2 > 9.0E-4D || this.positionUpdateTicks >= 20;
            boolean flag3 = d3 != 0.0D || d4 != 0.0D;

            if (this.ridingEntity == null)
            {
                if (flag2 && flag3)
                {
                    this.sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(this.posX, this.getEntityBoundingBox().minY, this.posZ, this.rotationYaw, this.rotationPitch, this.onGround));
                }
                else if (flag2)
                {
                    this.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(this.posX, this.getEntityBoundingBox().minY, this.posZ, this.onGround));
                }
                else if (flag3)
                {
                    this.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(this.rotationYaw, this.rotationPitch, this.onGround));
                }
                else
                {
                    this.sendQueue.addToSendQueue(new C03PacketPlayer(this.onGround));
                }
            }
            else
            {
                this.sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(this.motionX, -999.0D, this.motionZ, this.rotationYaw, this.rotationPitch, this.onGround));
                flag2 = false;
            }

            ++this.positionUpdateTicks;

            if (flag2)
            {
                this.lastReportedPosX = this.posX;
                this.lastReportedPosY = this.getEntityBoundingBox().minY;
                this.lastReportedPosZ = this.posZ;
                this.positionUpdateTicks = 0;
            }

            if (flag3)
            {
                this.lastReportedYaw = this.rotationYaw;
                this.lastReportedPitch = this.rotationPitch;
            }
        }
        
        this.func_8821Kns_0PP();
    }

    /**
     * Called when player presses the drop item key
     */
    public EntityItem dropOneItem(boolean dropAll)
    {
        C07PacketPlayerDigging.Action c07packetplayerdigging$action = dropAll ? C07PacketPlayerDigging.Action.DROP_ALL_ITEMS : C07PacketPlayerDigging.Action.DROP_ITEM;
        this.sendQueue.addToSendQueue(new C07PacketPlayerDigging(c07packetplayerdigging$action, BlockPos.ORIGIN, EnumFacing.DOWN));
        return null;
    }

    /**
     * Joins the passed in entity item with the world. Args: entityItem
     */
    protected void joinEntityItemWithWorld(EntityItem itemIn)
    {
    }

    /**
     * Sends a chat message from the player. Args: chatMessage
     */
    public void sendChatMessage(String message)
    {
        this.sendQueue.addToSendQueue(new C01PacketChatMessage(message));
    }

    /**
     * Swings the item the player is holding.
     */
    public void swingItem()
    {
        super.swingItem();
        this.sendQueue.addToSendQueue(new C0APacketAnimation());
    }

    public void respawnPlayer()
    {
    	BugUp.getInstance().spawn = true;
        this.sendQueue.addToSendQueue(new C16PacketClientStatus(C16PacketClientStatus.EnumState.PERFORM_RESPAWN));
    }

    /**
     * Deals damage to the entity. If its a EntityPlayer then will take damage from the armor first and then health
     * second with the reduced value. Args: damageAmount
     */
    protected void damageEntity(DamageSource damageSrc, float damageAmount)
    {
        if (!this.isEntityInvulnerable(damageSrc))
        {
            this.setHealth(this.getHealth() - damageAmount);
        }
    }

    /**
     * set current crafting inventory back to the 2x2 square
     */
    public void closeScreen()
    {
        this.sendQueue.addToSendQueue(new C0DPacketCloseWindow(this.openContainer.windowId));
        this.closeScreenAndDropStack();
    }

    public void closeScreenAndDropStack()
    {
        this.inventory.setItemStack((ItemStack)null);
        super.closeScreen();
        this.mc.displayGuiScreen((GuiScreen)null);
    }

    /**
     * Updates health locally.
     */
    public void setPlayerSPHealth(float health)
    {
        if (this.hasValidHealth)
        {
            float f = this.getHealth() - health;

            if (f <= 0.0F)
            {
                this.setHealth(health);

                if (f < 0.0F)
                {
                    this.hurtResistantTime = this.maxHurtResistantTime / 2;
                }
            }
            else
            {
                this.lastDamage = f;
                this.setHealth(this.getHealth());
                this.hurtResistantTime = this.maxHurtResistantTime;
                this.damageEntity(DamageSource.generic, f);
                this.hurtTime = this.maxHurtTime = 10;
            }
        }
        else
        {
            this.setHealth(health);
            this.hasValidHealth = true;
        }
    }

    /**
     * Adds a value to a statistic field.
     */
    public void addStat(StatBase stat, int amount)
    {
        if (stat != null)
        {
            if (stat.isIndependent)
            {
                super.addStat(stat, amount);
            }
        }
    }

    /**
     * Sends the player's abilities to the server (if there is one).
     */
    public void sendPlayerAbilities()
    {
        this.sendQueue.addToSendQueue(new C13PacketPlayerAbilities(this.capabilities));
    }

    /**
     * returns true if this is an EntityPlayerSP, or the logged in player.
     */
    public boolean isUser()
    {
        return true;
    }

    protected void sendHorseJump()
    {
        this.sendQueue.addToSendQueue(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.RIDING_JUMP, (int)(this.getHorseJumpPower() * 100.0F)));
    }

    public void sendHorseInventory()
    {
        this.sendQueue.addToSendQueue(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.OPEN_INVENTORY));
    }

    public void setClientBrand(String brand)
    {
        this.clientBrand = brand;
    }

    public String getClientBrand()
    {
        return this.clientBrand;
    }

    public StatFileWriter getStatFileWriter()
    {
        return this.statWriter;
    }

    public void addChatComponentMessage(IChatComponent chatComponent)
    {
        this.mc.ingameGUI.getChatGUI().printChatMessage(chatComponent);
    }

    protected boolean pushOutOfBlocks(double x, double y, double z)
    {
        if (this.noClip)
        {
            return false;
        }
        else
        {
            BlockPos blockpos = new BlockPos(x, y, z);
            double d0 = x - (double)blockpos.getX();
            double d1 = z - (double)blockpos.getZ();

            if (!this.isOpenBlockSpace(blockpos))
            {
                int i = -1;
                double d2 = 9999.0D;

                if (this.isOpenBlockSpace(blockpos.west()) && d0 < d2)
                {
                    d2 = d0;
                    i = 0;
                }

                if (this.isOpenBlockSpace(blockpos.east()) && 1.0D - d0 < d2)
                {
                    d2 = 1.0D - d0;
                    i = 1;
                }

                if (this.isOpenBlockSpace(blockpos.north()) && d1 < d2)
                {
                    d2 = d1;
                    i = 4;
                }

                if (this.isOpenBlockSpace(blockpos.south()) && 1.0D - d1 < d2)
                {
                    d2 = 1.0D - d1;
                    i = 5;
                }

                float f = 0.1F;

                if (i == 0)
                {
                    this.motionX = (double)(-f);
                }

                if (i == 1)
                {
                    this.motionX = (double)f;
                }

                if (i == 4)
                {
                    this.motionZ = (double)(-f);
                }

                if (i == 5)
                {
                    this.motionZ = (double)f;
                }
            }

            return false;
        }
    }

    /**
     * Returns true if the block at the given BlockPos and the block above it are NOT full cubes.
     */
    public boolean isOpenBlockSpace(BlockPos pos)
    {
        return !this.worldObj.getBlockState(pos).getBlock().isNormalCube() && !this.worldObj.getBlockState(pos.up()).getBlock().isNormalCube();
    }

    /**
     * Set sprinting switch for Entity.
     */
    public void setSprinting(boolean sprinting)
    {
        super.setSprinting(sprinting);
        this.sprintingTicksLeft = sprinting ? 600 : 0;
    }

    /**
     * Sets the current XP, total XP, and level number.
     */
    public void setXPStats(float currentXP, int maxXP, int level)
    {
        this.experience = currentXP;
        this.experienceTotal = maxXP;
        this.experienceLevel = level;
    }

    /**
     * Send a chat message to the CommandSender
     */
    public void addChatMessage(IChatComponent component)
    {
        this.mc.ingameGUI.getChatGUI().printChatMessage(component);
    }

    /**
     * Returns {@code true} if the CommandSender is allowed to execute the command, {@code false} if not
     */
    public boolean canCommandSenderUseCommand(int permLevel, String commandName)
    {
        return permLevel <= 0;
    }

    /**
     * Get the position in the world. <b>{@code null} is not allowed!</b> If you are not an entity in the world, return
     * the coordinates 0, 0, 0
     */
    public BlockPos getPosition()
    {
        return new BlockPos(this.posX + 0.5D, this.posY + 0.5D, this.posZ + 0.5D);
    }

    public void playSound(String name, float volume, float pitch)
    {
        this.worldObj.playSound(this.posX, this.posY, this.posZ, name, volume, pitch, false);
    }

    /**
     * Returns whether the entity is in a server world
     */
    public boolean isServerWorld()
    {
        return true;
    }

    public boolean isRidingHorse()
    {
        return this.ridingEntity != null && this.ridingEntity instanceof EntityHorse && ((EntityHorse)this.ridingEntity).isHorseSaddled();
    }

    public float getHorseJumpPower()
    {
        return this.horseJumpPower;
    }

    public void openEditSign(TileEntitySign signTile)
    {
        this.mc.displayGuiScreen(new GuiEditSign(signTile));
    }

    public void openEditCommandBlock(CommandBlockLogic cmdBlockLogic)
    {
        this.mc.displayGuiScreen(new GuiCommandBlock(cmdBlockLogic));
    }

    /**
     * Displays the GUI for interacting with a book.
     */
    public void displayGUIBook(ItemStack bookStack)
    {
        Item item = bookStack.getItem();

        if (item == Items.writable_book)
        {
            this.mc.displayGuiScreen(new GuiScreenBook(this, bookStack, true));
        }
    }

    /**
     * Displays the GUI for interacting with a chest inventory. Args: chestInventory
     */
    public void displayGUIChest(IInventory chestInventory)
    {
        String s = chestInventory instanceof IInteractionObject ? ((IInteractionObject)chestInventory).getGuiID() : "minecraft:container";

        if ("minecraft:chest".equals(s))
        {
            this.mc.displayGuiScreen(new GuiChest(this.inventory, chestInventory));
        }
        else if ("minecraft:hopper".equals(s))
        {
            this.mc.displayGuiScreen(new GuiHopper(this.inventory, chestInventory));
        }
        else if ("minecraft:furnace".equals(s))
        {
            this.mc.displayGuiScreen(new GuiFurnace(this.inventory, chestInventory));
        }
        else if ("minecraft:brewing_stand".equals(s))
        {
            this.mc.displayGuiScreen(new GuiBrewingStand(this.inventory, chestInventory));
        }
        else if ("minecraft:beacon".equals(s))
        {
            this.mc.displayGuiScreen(new GuiBeacon(this.inventory, chestInventory));
        }
        else if (!"minecraft:dispenser".equals(s) && !"minecraft:dropper".equals(s))
        {
            this.mc.displayGuiScreen(new GuiChest(this.inventory, chestInventory));
        }
        else
        {
            this.mc.displayGuiScreen(new GuiDispenser(this.inventory, chestInventory));
        }
    }

    public void displayGUIHorse(EntityHorse horse, IInventory horseInventory)
    {
        this.mc.displayGuiScreen(new GuiScreenHorseInventory(this.inventory, horseInventory, horse));
    }

    public void displayGui(IInteractionObject guiOwner)
    {
        String s = guiOwner.getGuiID();

        if ("minecraft:crafting_table".equals(s))
        {
            this.mc.displayGuiScreen(new GuiCrafting(this.inventory, this.worldObj));
        }
        else if ("minecraft:enchanting_table".equals(s))
        {
            this.mc.displayGuiScreen(new GuiEnchantment(this.inventory, this.worldObj, guiOwner));
        }
        else if ("minecraft:anvil".equals(s))
        {
            this.mc.displayGuiScreen(new GuiRepair(this.inventory, this.worldObj));
        }
    }

    public void displayVillagerTradeGui(IMerchant villager)
    {
        this.mc.displayGuiScreen(new GuiMerchant(this.inventory, villager, this.worldObj));
    }

    /**
     * Called when the player performs a critical hit on the Entity. Args: entity that was hit critically
     */
    public void onCriticalHit(Entity entityHit)
    {
        this.mc.effectRenderer.emitParticleAtEntity(entityHit, EnumParticleTypes.CRIT);
    }

    public void onEnchantmentCritical(Entity entityHit)
    {
        this.mc.effectRenderer.emitParticleAtEntity(entityHit, EnumParticleTypes.CRIT_MAGIC);
    }

    /**
     * Returns if this entity is sneaking.
     */
    public boolean isSneaking()
    {
        boolean flag = this.movementInput != null ? this.movementInput.sneak : false;
        return flag && !this.sleeping;
    }

    public void updateEntityActionState()
    {
        super.updateEntityActionState();

        if (this.isCurrentViewEntity())
        {
            this.moveStrafing = this.movementInput.moveStrafe;
            this.moveForward = this.movementInput.moveForward;
            this.isJumping = this.movementInput.jump;
            this.prevRenderArmYaw = this.renderArmYaw;
            this.prevRenderArmPitch = this.renderArmPitch;
            this.renderArmPitch = (float)((double)this.renderArmPitch + (double)(this.rotationPitch - this.renderArmPitch) * 0.5D);
            this.renderArmYaw = (float)((double)this.renderArmYaw + (double)(this.rotationYaw - this.renderArmYaw) * 0.5D);
        }
    }

    protected boolean isCurrentViewEntity()
    {
        return this.mc.getRenderViewEntity() == this;
    }

    /**
     * Called frequently so the entity can update its state every tick as required. For example, zombies and skeletons
     * use this to react to sunlight and start to burn.
     */
    public void onLivingUpdate()
    {
    	EventManager.callEvent(new LivingUpdateEvent(LivingUpdateEvent.State.PRE));
        if (this.sprintingTicksLeft > 0)
        {
            --this.sprintingTicksLeft;

            if (this.sprintingTicksLeft == 0)
            {
                this.setSprinting(false);
            }
        }

        if (this.sprintToggleTimer > 0)
        {
            --this.sprintToggleTimer;
        }

        this.prevTimeInPortal = this.timeInPortal;

        if (this.inPortal)
        {
            if (this.mc.currentScreen != null && !this.mc.currentScreen.doesGuiPauseGame())
            {
                this.mc.displayGuiScreen((GuiScreen)null);
            }

            if (this.timeInPortal == 0.0F)
            {
                this.mc.getSoundHandler().playSound(PositionedSoundRecord.create(new ResourceLocation("portal.trigger"), this.rand.nextFloat() * 0.4F + 0.8F));
            }

            this.timeInPortal += 0.0125F;

            if (this.timeInPortal >= 1.0F)
            {
                this.timeInPortal = 1.0F;
            }

            this.inPortal = false;
        }
        else if (this.isPotionActive(Potion.confusion) && this.getActivePotionEffect(Potion.confusion).getDuration() > 60)
        {
            this.timeInPortal += 0.006666667F;

            if (this.timeInPortal > 1.0F)
            {
                this.timeInPortal = 1.0F;
            }
        }
        else
        {
            if (this.timeInPortal > 0.0F)
            {
                this.timeInPortal -= 0.05F;
            }

            if (this.timeInPortal < 0.0F)
            {
                this.timeInPortal = 0.0F;
            }
        }

        if (this.timeUntilPortal > 0)
        {
            --this.timeUntilPortal;
        }

        boolean flag = this.movementInput.jump;
        boolean flag1 = this.movementInput.sneak;
        float f = 0.8F;
        boolean flag2 = this.movementInput.moveForward >= f;
        this.movementInput.updatePlayerMoveState();

        if (this.isUsingItem() && !this.isRiding() && !ModuleManager.getModuleState(NoSlow.class))
        {
            this.movementInput.moveStrafe *= 0.2F;
            this.movementInput.moveForward *= 0.2F;
            this.sprintToggleTimer = 0;
        }

        this.pushOutOfBlocks(this.posX - (double)this.width * 0.35D, this.getEntityBoundingBox().minY + 0.5D, this.posZ + (double)this.width * 0.35D);
        this.pushOutOfBlocks(this.posX - (double)this.width * 0.35D, this.getEntityBoundingBox().minY + 0.5D, this.posZ - (double)this.width * 0.35D);
        this.pushOutOfBlocks(this.posX + (double)this.width * 0.35D, this.getEntityBoundingBox().minY + 0.5D, this.posZ - (double)this.width * 0.35D);
        this.pushOutOfBlocks(this.posX + (double)this.width * 0.35D, this.getEntityBoundingBox().minY + 0.5D, this.posZ + (double)this.width * 0.35D);
        boolean flag3 = (float)this.getFoodStats().getFoodLevel() > 6.0F || this.capabilities.allowFlying;
        EventManager.callEvent(new LivingUpdateEvent(LivingUpdateEvent.State.INIT));
        
        if (this.onGround && !flag1 && !flag2 && this.movementInput.moveForward >= f && !this.isSprinting() && flag3 && !this.isUsingItem() && !this.isPotionActive(Potion.blindness))
        {
            if (this.sprintToggleTimer <= 0 && !this.mc.gameSettings.keyBindSprint.isKeyDown())
            {
                this.sprintToggleTimer = 7;
            }
            else
            {
                this.setSprinting(true);
            }
        }

        if (!this.isSprinting() && this.movementInput.moveForward >= f && flag3 && !this.isUsingItem() && !this.isPotionActive(Potion.blindness) && this.mc.gameSettings.keyBindSprint.isKeyDown())
        {
            this.setSprinting(true);
        }

        if (this.isSprinting() && (this.movementInput.moveForward < f || this.isCollidedHorizontally || !flag3))
        {
            this.setSprinting(false);
        }

        if (this.capabilities.allowFlying)
        {
            if (this.mc.playerController.isSpectatorMode())
            {
                if (!this.capabilities.isFlying)
                {
                    this.capabilities.isFlying = true;
                    this.sendPlayerAbilities();
                }
            }
            else if (!flag && this.movementInput.jump)
            {
                if (this.flyToggleTimer == 0)
                {
                    this.flyToggleTimer = 7;
                }
                else
                {
                    this.capabilities.isFlying = !this.capabilities.isFlying;
                    this.sendPlayerAbilities();
                    this.flyToggleTimer = 0;
                }
            }
        }

        if (this.capabilities.isFlying && this.isCurrentViewEntity())
        {
            if (this.movementInput.sneak)
            {
                this.motionY -= (double)(this.capabilities.getFlySpeed() * 3.0F);
            }

            if (this.movementInput.jump)
            {
                this.motionY += (double)(this.capabilities.getFlySpeed() * 3.0F);
            }
        }

        if (this.isRidingHorse())
        {
            if (this.horseJumpPowerCounter < 0)
            {
                ++this.horseJumpPowerCounter;

                if (this.horseJumpPowerCounter == 0)
                {
                    this.horseJumpPower = 0.0F;
                }
            }

            if (flag && !this.movementInput.jump)
            {
                this.horseJumpPowerCounter = -10;
                this.sendHorseJump();
            }
            else if (!flag && this.movementInput.jump)
            {
                this.horseJumpPowerCounter = 0;
                this.horseJumpPower = 0.0F;
            }
            else if (flag)
            {
                ++this.horseJumpPowerCounter;

                if (this.horseJumpPowerCounter < 10)
                {
                    this.horseJumpPower = (float)this.horseJumpPowerCounter * 0.1F;
                }
                else
                {
                    this.horseJumpPower = 0.8F + 2.0F / (float)(this.horseJumpPowerCounter - 9) * 0.1F;
                }
            }
        }
        else
        {
            this.horseJumpPower = 0.0F;
        }

        super.onLivingUpdate();

        if (this.onGround && this.capabilities.isFlying && !this.mc.playerController.isSpectatorMode())
        {
            this.capabilities.isFlying = false;
            this.sendPlayerAbilities();
        }
        
        EventManager.callEvent(new LivingUpdateEvent(LivingUpdateEvent.State.POST));
    }

	public void onMoveEntity(double x, double y, double z) {
		 if (this.noClip)
	        {
	            this.setEntityBoundingBox(this.getEntityBoundingBox().offset(x, y, z));
	            this.resetPositionToBB();
	        }
	        else
	        {
	            this.worldObj.theProfiler.startSection("move");
	            double d0 = this.posX;
	            double d1 = this.posY;
	            double d2 = this.posZ;

	            if (this.isInWeb)
	            {
	                this.isInWeb = false;
	                x *= 0.25D;
	                y *= 0.05000000074505806D;
	                z *= 0.25D;
	                this.motionX = 0.0D;
	                this.motionY = 0.0D;
	                this.motionZ = 0.0D;
	            }

	            double d3 = x;
	            double d4 = y;
	            double d5 = z;
	            boolean flag = this.onGround && this.isSneaking() && this instanceof EntityPlayer;
	            SafeWalkEvent eee = new SafeWalkEvent(false);
	            EventManager.callEvent(eee);
	            
	            if (flag || eee.getSafe())
	            {
	                double d6;

	                for (d6 = 0.05D; x != 0.0D && this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox().offset(x, -1.0D, 0.0D)).isEmpty(); d3 = x)
	                {
	                    if (x < d6 && x >= -d6)
	                    {
	                        x = 0.0D;
	                    }
	                    else if (x > 0.0D)
	                    {
	                        x -= d6;
	                    }
	                    else
	                    {
	                        x += d6;
	                    }
	                }

	                for (; z != 0.0D && this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox().offset(0.0D, -1.0D, z)).isEmpty(); d5 = z)
	                {
	                    if (z < d6 && z >= -d6)
	                    {
	                        z = 0.0D;
	                    }
	                    else if (z > 0.0D)
	                    {
	                        z -= d6;
	                    }
	                    else
	                    {
	                        z += d6;
	                    }
	                }

	                for (; x != 0.0D && z != 0.0D && this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox().offset(x, -1.0D, z)).isEmpty(); d5 = z)
	                {
	                    if (x < d6 && x >= -d6)
	                    {
	                        x = 0.0D;
	                    }
	                    else if (x > 0.0D)
	                    {
	                        x -= d6;
	                    }
	                    else
	                    {
	                        x += d6;
	                    }

	                    d3 = x;

	                    if (z < d6 && z >= -d6)
	                    {
	                        z = 0.0D;
	                    }
	                    else if (z > 0.0D)
	                    {
	                        z -= d6;
	                    }
	                    else
	                    {
	                        z += d6;
	                    }
	                }
	            }

	            List<AxisAlignedBB> list1 = this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox().addCoord(x, y, z));
	            AxisAlignedBB axisalignedbb = this.getEntityBoundingBox();

	            for (AxisAlignedBB axisalignedbb1 : list1)
	            {
	                y = axisalignedbb1.calculateYOffset(this.getEntityBoundingBox(), y);
	            }

	            this.setEntityBoundingBox(this.getEntityBoundingBox().offset(0.0D, y, 0.0D));
	            boolean flag1 = this.onGround || d4 != y && d4 < 0.0D;

	            for (AxisAlignedBB axisalignedbb2 : list1)
	            {
	                x = axisalignedbb2.calculateXOffset(this.getEntityBoundingBox(), x);
	            }

	            this.setEntityBoundingBox(this.getEntityBoundingBox().offset(x, 0.0D, 0.0D));

	            for (AxisAlignedBB axisalignedbb13 : list1)
	            {
	                z = axisalignedbb13.calculateZOffset(this.getEntityBoundingBox(), z);
	            }

	            this.setEntityBoundingBox(this.getEntityBoundingBox().offset(0.0D, 0.0D, z));

	            if (this.stepHeight > 0.0F && flag1 && (d3 != x || d5 != z))
	            {
	                double d11 = x;
	                double d7 = y;
	                double d8 = z;
	                AxisAlignedBB axisalignedbb3 = this.getEntityBoundingBox();
	                this.setEntityBoundingBox(axisalignedbb);
	                y = (double)this.stepHeight;
	                List<AxisAlignedBB> list = this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox().addCoord(d3, y, d5));
	                AxisAlignedBB axisalignedbb4 = this.getEntityBoundingBox();
	                AxisAlignedBB axisalignedbb5 = axisalignedbb4.addCoord(d3, 0.0D, d5);
	                double d9 = y;

	                for (AxisAlignedBB axisalignedbb6 : list)
	                {
	                    d9 = axisalignedbb6.calculateYOffset(axisalignedbb5, d9);
	                }

	                axisalignedbb4 = axisalignedbb4.offset(0.0D, d9, 0.0D);
	                double d15 = d3;

	                for (AxisAlignedBB axisalignedbb7 : list)
	                {
	                    d15 = axisalignedbb7.calculateXOffset(axisalignedbb4, d15);
	                }

	                axisalignedbb4 = axisalignedbb4.offset(d15, 0.0D, 0.0D);
	                double d16 = d5;

	                for (AxisAlignedBB axisalignedbb8 : list)
	                {
	                    d16 = axisalignedbb8.calculateZOffset(axisalignedbb4, d16);
	                }

	                axisalignedbb4 = axisalignedbb4.offset(0.0D, 0.0D, d16);
	                AxisAlignedBB axisalignedbb14 = this.getEntityBoundingBox();
	                double d17 = y;

	                for (AxisAlignedBB axisalignedbb9 : list)
	                {
	                    d17 = axisalignedbb9.calculateYOffset(axisalignedbb14, d17);
	                }

	                axisalignedbb14 = axisalignedbb14.offset(0.0D, d17, 0.0D);
	                double d18 = d3;

	                for (AxisAlignedBB axisalignedbb10 : list)
	                {
	                    d18 = axisalignedbb10.calculateXOffset(axisalignedbb14, d18);
	                }

	                axisalignedbb14 = axisalignedbb14.offset(d18, 0.0D, 0.0D);
	                double d19 = d5;

	                for (AxisAlignedBB axisalignedbb11 : list)
	                {
	                    d19 = axisalignedbb11.calculateZOffset(axisalignedbb14, d19);
	                }

	                axisalignedbb14 = axisalignedbb14.offset(0.0D, 0.0D, d19);
	                double d20 = d15 * d15 + d16 * d16;
	                double d10 = d18 * d18 + d19 * d19;

	                if (d20 > d10)
	                {
	                    x = d15;
	                    z = d16;
	                    y = -d9;
	                    this.setEntityBoundingBox(axisalignedbb4);
	                }
	                else
	                {
	                    x = d18;
	                    z = d19;
	                    y = -d17;
	                    this.setEntityBoundingBox(axisalignedbb14);
	                }

	                for (AxisAlignedBB axisalignedbb12 : list)
	                {
	                    y = axisalignedbb12.calculateYOffset(this.getEntityBoundingBox(), y);
	                }

	                this.setEntityBoundingBox(this.getEntityBoundingBox().offset(0.0D, y, 0.0D));

	                if (d11 * d11 + d8 * d8 >= x * x + z * z)
	                {
	                    x = d11;
	                    y = d7;
	                    z = d8;
	                    this.setEntityBoundingBox(axisalignedbb3);
	                }
	            }

	            this.worldObj.theProfiler.endSection();
	            this.worldObj.theProfiler.startSection("rest");
	            this.resetPositionToBB();
	            this.isCollidedHorizontally = d3 != x || d5 != z;
	            this.isCollidedVertically = d4 != y;
	            this.onGround = this.isCollidedVertically && d4 < 0.0D;
	            this.isCollided = this.isCollidedHorizontally || this.isCollidedVertically;
	            int i = MathHelper.floor_double(this.posX);
	            int j = MathHelper.floor_double(this.posY - 0.20000000298023224D);
	            int k = MathHelper.floor_double(this.posZ);
	            BlockPos blockpos = new BlockPos(i, j, k);
	            Block block1 = this.worldObj.getBlockState(blockpos).getBlock();

	            if (block1.getMaterial() == Material.air)
	            {
	                Block block = this.worldObj.getBlockState(blockpos.down()).getBlock();

	                if (block instanceof BlockFence || block instanceof BlockWall || block instanceof BlockFenceGate)
	                {
	                    block1 = block;
	                    blockpos = blockpos.down();
	                }
	            }

	            this.updateFallState(y, this.onGround, block1, blockpos);

	            if (d3 != x)
	            {
	                this.motionX = 0.0D;
	            }

	            if (d5 != z)
	            {
	                this.motionZ = 0.0D;
	            }

	            if (d4 != y)
	            {
	                block1.onLanded(this.worldObj, this);
	            }

	            if (this.canTriggerWalking() && !flag && this.ridingEntity == null)
	            {
	                double d12 = this.posX - d0;
	                double d13 = this.posY - d1;
	                double d14 = this.posZ - d2;

	                if (block1 != Blocks.ladder)
	                {
	                    d13 = 0.0D;
	                }

	                if (block1 != null && this.onGround)
	                {
	                    block1.onEntityCollidedWithBlock(this.worldObj, blockpos, this);
	                }

	                this.distanceWalkedModified = (float)((double)this.distanceWalkedModified + (double)MathHelper.sqrt_double(d12 * d12 + d14 * d14) * 0.6D);
	                this.distanceWalkedOnStepModified = (float)((double)this.distanceWalkedOnStepModified + (double)MathHelper.sqrt_double(d12 * d12 + d13 * d13 + d14 * d14) * 0.6D);

	                if (this.distanceWalkedOnStepModified > (float)this.nextStepDistance && block1.getMaterial() != Material.air)
	                {
	                    this.nextStepDistance = (int)this.distanceWalkedOnStepModified + 1;

	                    if (this.isInWater())
	                    {
	                        float f = MathHelper.sqrt_double(this.motionX * this.motionX * 0.20000000298023224D + this.motionY * this.motionY + this.motionZ * this.motionZ * 0.20000000298023224D) * 0.35F;

	                        if (f > 1.0F)
	                        {
	                            f = 1.0F;
	                        }

	                        this.playSound(this.getSwimSound(), f, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
	                    }

	                    this.playStepSound(blockpos, block1);
	                }
	            }

	            try
	            {
	                this.doBlockCollisions();
	            }
	            catch (Throwable throwable)
	            {
	                CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Checking entity block collision");
	                CrashReportCategory crashreportcategory = crashreport.makeCategory("Entity being checked for collision");
	                this.addEntityCrashInfo(crashreportcategory);
	                throw new ReportedException(crashreport);
	            }

	            boolean flag2 = this.isWet();

	            if (this.worldObj.isFlammableWithin(this.getEntityBoundingBox().contract(0.001D, 0.001D, 0.001D)))
	            {
	                this.dealFireDamage(1);

	                if (!flag2)
	                {
	                    ++this.fire;

	                    if (this.fire == 0)
	                    {
	                        this.setFire(8);
	                    }
	                }
	            }
	            else if (this.fire <= 0)
	            {
	                this.fire = -this.fireResistance;
	            }

	            if (flag2 && this.fire > 0)
	            {
	                this.playSound("random.fizz", 0.7F, 1.6F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
	                this.fire = -this.fireResistance;
	            }

	            this.worldObj.theProfiler.endSection();
	        }
	}

	public boolean moving() {
		return this.moveForward > 0.0 | this.moveStrafing > 0.0;
	}

	public float getSpeed() {
		return (float) Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
	}

	public void setSpeed(double speed) {
        this.motionX = -MathHelper.sin(this.getDirection()) * speed;
        this.motionZ = MathHelper.cos(this.getDirection()) * speed;
	}

	
    public float getDirection() {
        float yaw = this.rotationYaw;
        final float forward = this.moveForward;
        final float strafe = this.moveStrafing;
        yaw += ((forward < 0.0f) ? 180 : 0);
        
        if (strafe < 0.0f) {
            yaw += ((forward < 0.0f) ? -45.0f : ((forward == 0.0f) ? 90.0f : 45.0f));
        }
        
        if (strafe > 0.0f) {
            yaw -= ((forward < 0.0f) ? -45.0f : ((forward == 0.0f) ? 90.0f : 45.0f));
        }
        
        return yaw * 0.017453292f;
    }
    
    public void setMoveSpeed(final double speed) {
        double forward = this.movementInput.moveForward;
        double strafe = this.movementInput.moveStrafe;
        float yaw = this.rotationYaw;
        
        if (forward == 0.0 && strafe == 0.0) {
        	this.motionX = 0.0;
        	this.motionZ = 0.0;
        } else {
			if (forward != 0.0) {
				if (strafe > 0.0) {
					yaw += ((forward > 0.0) ? -45 : 45);
				} else if (strafe < 0.0) {
					yaw += ((forward > 0.0) ? 45 : -45);
				}
				strafe = 0.0;
				if (forward > 0.0) {
					forward = 1.0;
				} else if (forward < 0.0) {
					forward = -1.0;
				}
			}
			
            this.motionX = forward * speed * Math.cos(Math.toRadians((double)(yaw + 90.0f))) + strafe * speed * Math.sin(Math.toRadians((double)(yaw + 90.0f)));
            this.motionZ = forward * speed * Math.sin(Math.toRadians((double)(yaw + 90.0f))) - strafe * speed * Math.cos(Math.toRadians((double)(yaw + 90.0f)));
        }
    }
}